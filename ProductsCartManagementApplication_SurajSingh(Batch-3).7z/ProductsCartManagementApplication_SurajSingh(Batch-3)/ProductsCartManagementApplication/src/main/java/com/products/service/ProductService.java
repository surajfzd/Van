package com.products.service;

import java.util.List;

import com.products.beans.Products;
import com.products.exception.DuplicateProductIdException;
import com.products.exception.ProductNotFoundException;

public interface ProductService 
{

	public Products createProduct(Products products) throws DuplicateProductIdException, ProductNotFoundException;
	public Products updateProduct(Products products, String id) throws ProductNotFoundException;
	public Products deleteProduct(String id) throws ProductNotFoundException;
	public List<Products> viewProducts() throws ProductNotFoundException;
	public Products findProduct(String id) throws ProductNotFoundException;
}
