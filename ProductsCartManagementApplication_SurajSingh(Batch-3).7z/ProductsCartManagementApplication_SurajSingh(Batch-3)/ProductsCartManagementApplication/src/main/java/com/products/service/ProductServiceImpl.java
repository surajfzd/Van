package com.products.service;

import java.util.List;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.products.beans.Products;
import com.products.exception.DuplicateProductIdException;
import com.products.exception.ProductNotFoundException;
import com.products.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo productRepo;
	
//Method to save product
	@Override
	public Products createProduct(Products products) throws DuplicateProductIdException, ProductNotFoundException 
	{

		if (productRepo.findById(products.getId()) == null)
		{
			return productRepo.save(products);
		}
		else
		{
			throw new DuplicateProductIdException("Duplicate product please enter another product id");
		}
	}

//Method to delete product by id
	@Override
	public Products deleteProduct(String id) throws ProductNotFoundException 
	{
		Products product;
		product = productRepo.findById(id);
		if (product != null) 
		{
			return productRepo.deleteById(product);
		} 
		else
			throw new ProductNotFoundException();
	}

//Method to show all products
	@Override
	public List<Products> viewProducts() throws ProductNotFoundException 
	{

		List<Products> listProduct = productRepo.findAll();
		if (listProduct.isEmpty()) 
		{
			throw new ProductNotFoundException();
		} 
		else
			return listProduct;

	}

//Method to find product by id
	@Override
	public Products findProduct(String id) throws ProductNotFoundException 
	{

		Products product = productRepo.findById(id);
		if (product == null)
			{
				throw new ProductNotFoundException();
			}
		else
			return product;
	}

//Method to update product by id
	@Override
	public Products updateProduct(Products products, String id) throws ProductNotFoundException 
	{

		Products product = productRepo.findById(id);
		if (product == null)
		{
			throw new ProductNotFoundException();
		}
			
		else {
			return productRepo.update(product, products);
		}
	}

}