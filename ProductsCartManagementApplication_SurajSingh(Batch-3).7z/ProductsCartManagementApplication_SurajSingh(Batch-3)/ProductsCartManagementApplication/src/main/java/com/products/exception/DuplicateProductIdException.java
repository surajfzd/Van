package com.products.exception;

public class DuplicateProductIdException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
public DuplicateProductIdException(String msg)
{
	super(msg);
}
}
