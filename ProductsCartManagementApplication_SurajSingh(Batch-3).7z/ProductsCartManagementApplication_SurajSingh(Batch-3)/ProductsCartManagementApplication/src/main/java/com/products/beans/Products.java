package com.products.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Entity
@Table(name = "product")
public class Products 
{
//declaring id variable and Validating it
	@Pattern(regexp = "[a-zA-Z]{1}[0-9]{1,2}", message = "Invalid ID: it must start with an alphabet and after that atmost two digits")
	@Id
	private String id;

//declaring name variable and Validating it
	@NotNull(message = "You passed null, Provide product name")
	@Size(min = 2, max = 20, message = "You entered an invalid name, name must contain atleast 2 and atmost 20 alphabets")
	private String name;

//declaring model variable and Validating it
	@NotNull(message = "You passed null, Provide model name")
	@Size(min = 2, max = 10, message = "You entered an invalid model name, name must contain atleast 2 and atmost 20 alphabets")
	private String model;

//declaring price variable and Validating it
	@NotNull(message = "You passed null, Provide product price")
	@Positive(message = "price should be positive")
	private int price;

	public String getId() 
	{
		return id;
	}

	public void setId(String id) 
	{
		this.id = id;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public String getModel() 
	{
		return model;
	}

	public void setModel(String model) 
	{
		this.model = model;
	}

	public int getPrice() 
	{
		return price;
	}

	public void setPrice(int price) 
	{
		this.price = price;
	}

}
