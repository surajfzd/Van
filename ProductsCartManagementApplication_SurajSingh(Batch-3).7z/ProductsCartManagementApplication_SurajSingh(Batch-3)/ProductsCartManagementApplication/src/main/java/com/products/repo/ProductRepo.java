package com.products.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.products.beans.Products;
import com.products.exception.DuplicateProductIdException;
import com.products.exception.ProductNotFoundException;

@Repository
public interface ProductRepo{

	Products findById(String id) throws ProductNotFoundException;

	Products save(Products products) throws DuplicateProductIdException, ProductNotFoundException;

	Products deleteById(Products products) throws ProductNotFoundException;

	List<Products> findAll() throws ProductNotFoundException;

	Products update(Products products, Products product) throws ProductNotFoundException;
	
	
	

}